import "file-loader?name=styles.css!./styles.css";
import "file-loader?name=./scripts/utils.js!./scripts/utils.js";
